# LUMESKIN — Sitio Web Standalone

Spa & Centro de Belleza en Celaya, Guanajuato.

## Despliegue en Vercel

1. Sube esta carpeta a GitHub.
2. En [vercel.com](https://vercel.com) importa el repo.
3. Vercel detecta automáticamente Vite. No necesitas cambiar nada.
4. Dale **Deploy**.

---

## Personalización

Todo el contenido editable está en **ún solo archivo**:

```
src/pages/Landing.tsx
```

### Cambiar teléfono de WhatsApp

Busca `PHONE_NUMBER` y reemplaza el número (sin `+` ni espacios):
```ts
const PHONE_NUMBER = "524611693332";
```

### Cambiar textos, precios y tratamientos

Busca el objeto `treatments` (~línea 50) y edita.

### Cambiar imágenes

Reemplaza las URLs de Unsplash en `galleryImages`, el hero, y la sección Nosotros.

### Cambiar horarios

Busca la sección de Contacto y edita el texto.

---

## Desarrollo local

```bash
npm install
npm run dev
```

Abre `http://localhost:5173`

## Construir para producción

```bash
npm run build
```

Genera `dist/` con el sitio estático.
