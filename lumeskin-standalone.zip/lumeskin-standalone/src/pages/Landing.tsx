import { useState, useEffect, useCallback } from "react";
import {
  Menu, X, ChevronRight, Phone, MapPin, Clock,
  Facebook, MessageCircle, Star, Sparkles, Heart,
} from "lucide-react";

const customStyles = `
  .lumeskin-root {
    --color-cream: #FDFBF7;
    --color-cream-dark: #F4EFEB;
    --color-dusty-rose: #D8B4B5;
    --color-rose-dark: #B98B8C;
    --color-soft-gold: #C9A66B;
    --color-sage: #A3B19B;
    --color-text-main: #4A403A;
    --color-text-light: #7A6F69;
    font-family: 'Montserrat', sans-serif;
    color: var(--color-text-main);
    background-color: var(--color-cream);
    overflow-x: hidden;
  }
  .lumeskin-root h1,.lumeskin-root h2,.lumeskin-root h3,.lumeskin-root h4,.lumeskin-root .font-serif {
    font-family: 'Playfair Display', serif;
  }
  .lumeskin-bg-cream { background-color: var(--color-cream); }
  .lumeskin-bg-cream-dark { background-color: var(--color-cream-dark); }
  .lumeskin-bg-rose { background-color: var(--color-dusty-rose); }
  .lumeskin-bg-sage { background-color: var(--color-sage); }
  .lumeskin-text-main { color: var(--color-text-main); }
  .lumeskin-text-light { color: var(--color-text-light); }
  .lumeskin-text-rose { color: var(--color-rose-dark); }
  .fade-in-up {
    opacity: 0;
    transform: translateY(28px);
    transition: opacity 0.7s ease-out, transform 0.7s ease-out;
    will-change: opacity, transform;
  }
  .fade-in-up.visible { opacity: 1; transform: translateY(0); }
  .stagger-2 { transition-delay: 0.15s; }
  .no-scrollbar::-webkit-scrollbar { display: none; }
  .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
`;

// Reusable intersection observer hook
function useIntersectionObserver() {
  const [elements, setElements] = useState<Element[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [elements]);

  const ref = useCallback((el: HTMLElement | null) => {
    if (el) setElements((prev) => (prev.includes(el) ? prev : [...prev, el]));
  }, []);

  return ref;
}

const PHONE_NUMBER = "524611693332";
const makeWhatsappLink = (text: string) =>
  `https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent(text)}`;

const CTAs = {
  general: makeWhatsappLink("Hola, quiero agendar una cita en Lumeskin"),
  treatment: (name: string) =>
    makeWhatsappLink(`Hola, quiero información sobre el tratamiento de ${name}`),
};

const treatments = {
  faciales: [
    { name: "Limpieza facial profunda", price: "$450", desc: "Elimina impurezas y renueva tu piel desde la primera sesión" },
    { name: "Hidratación facial intensiva", price: "$500", desc: "Recupera la luminosidad y suavidad de tu piel" },
    { name: "Facial antiedad con colágeno", price: "$650", desc: "Reduce líneas de expresión y reafirma" },
  ],
  reductivos: [
    { name: "Tratamiento reductivo abdomen", price: "$550", desc: "Ayuda a reducir medidas en la zona abdominal" },
    { name: "Tratamiento reductivo piernas", price: "$550", desc: "Mejora la apariencia de la piel y reduce medidas" },
    { name: "Reafirmante corporal", price: "$600", desc: "Tonifica y reafirma la piel" },
  ],
  masajes: [
    { name: "Masaje relajante cuerpo completo (60 min)", price: "$500", desc: "Libera tensión y estrés de todo el cuerpo" },
    { name: "Masaje descontracturante", price: "$550", desc: "Enfocado en zonas de tensión muscular" },
    { name: "Masaje con piedras calientes", price: "$650", desc: "Relajación profunda con terapia de calor" },
  ],
  depilacion: [
    { name: "Piernas completas", price: "$250" },
    { name: "Media pierna", price: "$150" },
    { name: "Axilas", price: "$100" },
    { name: "Cejas", price: "$80" },
    { name: "Bigote", price: "$60" },
  ],
} as const;

const reviews = [
  { name: "María F.", text: "El ambiente es increíblemente relajante. El facial de hidratación dejó mi piel hermosa y suave. ¡Regresaré pronto!", rating: 5 },
  { name: "Ana P.", text: "Excelente atención y resultados reales desde la primera sesión en el tratamiento reductivo. Te hacen sentir súper especial.", rating: 5 },
  { name: "Sofía G.", text: "Tomé un masaje descontracturante y fue la mejor experiencia. El lugar huele delicioso y la música te transporta.", rating: 5 },
  { name: "Laura T.", text: "Súper profesionales con la depilación y el cuidado de la piel. Definitivamente mi lugar favorito en Celaya.", rating: 5 },
];

// Optimized Unsplash URLs: WebP + exact dimensions
const galleryImages = [
  { src: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Tratamiento facial" },
  { src: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Spa relajante" },
  { src: "https://images.unsplash.com/photo-1559599101-f09722fb4948?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Masaje corporal" },
  { src: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Tratamiento de espalda" },
  { src: "https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Cosméticos naturales" },
  { src: "https://images.unsplash.com/photo-1519415510236-718bdfcd89c8?q=75&w=600&auto=format&fit=crop&fm=webp", alt: "Ambiente del spa" },
];

type TreatmentKey = keyof typeof treatments;

export default function Landing() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TreatmentKey>("faciales");
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);
  const fadeRef = useIntersectionObserver();

  // Close lightbox with Escape key
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setLightboxImg(null); };
    if (lightboxImg) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [lightboxImg]);

  // Throttled scroll listener
  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          setIsScrolled(window.scrollY > 50);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = useCallback((id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (!el) return;
    const start = window.scrollY;
    const target = el.getBoundingClientRect().top + start - 72;
    const distance = target - start;
    const duration = Math.min(900, Math.max(400, Math.abs(distance) * 0.4));
    let startTime: number | null = null;
    const ease = (t: number) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    const step = (ts: number) => {
      if (!startTime) startTime = ts;
      const p = Math.min((ts - startTime) / duration, 1);
      window.scrollTo(0, start + distance * ease(p));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, []);

  const navLinks: { label: string; id: string }[] = [
    { label: "Nosotros", id: "nosotros" },
    { label: "Tratamientos", id: "tratamientos" },
    { label: "Galería", id: "galeria" },
    { label: "Contacto", id: "contacto" },
  ];

  return (
    <div className="lumeskin-root min-h-screen relative w-full">
      <style>{customStyles}</style>

      {/* WhatsApp FAB */}
      <a
        href={CTAs.general}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Agendar cita por WhatsApp"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex items-center justify-center w-[60px] h-[60px]"
      >
        <MessageCircle size={30} />
      </a>

      {/* Navigation */}
      <nav
        role="navigation"
        aria-label="Menú principal"
        className={`fixed top-0 w-full z-40 transition-all duration-300 ${
          isScrolled ? "bg-white/95 backdrop-blur-sm shadow-sm py-4" : "bg-transparent py-6"
        }`}
      >
        <div className="container mx-auto px-6 lg:px-12 flex justify-between items-center">
          <button
            onClick={() => scrollToSection("hero")}
            aria-label="Ir al inicio"
            className="font-serif text-2xl tracking-widest uppercase font-bold lumeskin-text-main"
          >
            Lumeskin
          </button>

          <div className="hidden md:flex items-center space-x-8 text-sm font-medium tracking-wide text-gray-800">
            {navLinks.map(({ label, id }) => (
              <button
                key={id}
                onClick={() => scrollToSection(id)}
                className="hover:text-[var(--color-rose-dark)] transition-colors"
              >
                {label}
              </button>
            ))}
            <a
              href={CTAs.general}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2 border border-[var(--color-text-main)] rounded-full hover:bg-[var(--color-text-main)] hover:text-white transition-colors"
            >
              Agendar cita
            </a>
          </div>

          <button
            className="md:hidden p-2 text-gray-800"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? "Cerrar menú" : "Abrir menú"}
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-white/95 backdrop-blur-md shadow-md py-6 px-6 flex flex-col space-y-5">
            {navLinks.map(({ label, id }) => (
              <button
                key={id}
                onClick={() => scrollToSection(id)}
                className="text-left text-lg font-medium lumeskin-text-main"
              >
                {label}
              </button>
            ))}
            <a
              href={CTAs.general}
              target="_blank"
              rel="noopener noreferrer"
              className="text-center w-full bg-[var(--color-text-main)] text-white py-4 rounded-full font-medium"
            >
              Agendar cita
            </a>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section id="hero" className="relative h-[100dvh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 w-full h-full">
          <img
            src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=2000&auto=format&fit=crop&fm=webp"
            alt="Spa Lumeskin — ambiente relajante"
            className="w-full h-full object-cover"
            fetchPriority="high"
            loading="eager"
            decoding="sync"
            width={2000}
            height={1333}
          />
          <div className="absolute inset-0 bg-[#F4EFEB]/25 mix-blend-multiply" />
          <div className="absolute inset-0 bg-black/15" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto flex flex-col items-center">
          <span className="font-serif tracking-[0.3em] uppercase text-sm md:text-base mb-6 text-white drop-shadow-md">
            Lumeskin
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white mb-6 drop-shadow-lg leading-tight">
            Donde tu belleza es lo más importante
          </h1>
          <p className="text-lg md:text-xl text-white/95 mb-10 max-w-2xl font-light drop-shadow-md">
            Tratamientos faciales, reductivos y de relajación en Celaya, Guanajuato
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <a
              href={CTAs.general}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 bg-white text-[var(--color-text-main)] rounded-full hover:bg-[var(--color-cream-dark)] transition-colors shadow-lg font-medium flex items-center justify-center min-w-[200px]"
            >
              Agenda tu cita
            </a>
            <button
              onClick={() => scrollToSection("tratamientos")}
              className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white text-white rounded-full hover:bg-white/10 transition-colors font-medium flex items-center justify-center min-w-[200px]"
            >
              Ver tratamientos
            </button>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <button onClick={() => scrollToSection("nosotros")} aria-label="Ir a la siguiente sección" className="text-white/80 p-2">
            <div className="w-[30px] h-[50px] rounded-full border-2 border-white/80 flex justify-center pt-2">
              <div className="w-1.5 h-3 bg-white/80 rounded-full animate-pulse" />
            </div>
          </button>
        </div>
      </section>

      {/* Sobre Nosotros */}
      <section id="nosotros" className="py-24 lg:py-32 px-6 lumeskin-bg-cream-dark">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-center">
            <div ref={fadeRef} className="fade-in-up">
              <h2 className="text-3xl md:text-5xl mb-8 lumeskin-text-main">Tu bienestar, nuestro propósito</h2>
              <p className="text-lg lumeskin-text-light mb-6 leading-relaxed font-light">
                Somos un espacio donde tu belleza es lo más importante. Ofrecemos tratamientos que cuidan la salud de tu piel y tu bienestar, en un ambiente pensado para que te relajes y te sientas en confianza.
              </p>
              <p className="text-lg lumeskin-text-light mb-10 leading-relaxed font-light">
                Creemos en el cuidado personalizado. Cada piel es única, y por eso evaluamos tus necesidades para brindarte resultados reales que resalten tu belleza natural.
              </p>
              <ul className="space-y-4" aria-label="Características">
                <li className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full lumeskin-bg-rose flex items-center justify-center text-white shrink-0"><Sparkles size={20} /></div>
                  <span className="font-medium text-lg">Tratamientos personalizados</span>
                </li>
                <li className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full lumeskin-bg-sage flex items-center justify-center text-white shrink-0"><Heart size={20} /></div>
                  <span className="font-medium text-lg">Ambiente relajante</span>
                </li>
                <li className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-soft-gold)] flex items-center justify-center text-white shrink-0"><MapPin size={20} /></div>
                  <span className="font-medium text-lg">Atención en Celaya</span>
                </li>
              </ul>
            </div>
            <div ref={fadeRef} className="fade-in-up stagger-2 relative">
              <div className="aspect-[4/5] rounded-t-full overflow-hidden shadow-2xl relative z-10">
                <img
                  src="https://images.unsplash.com/photo-1552693673-1bf958298935?q=80&w=900&auto=format&fit=crop&fm=webp"
                  alt="Tratamiento relajante en Lumeskin"
                  className="w-full h-full object-cover"
                  loading="lazy"
                  decoding="async"
                  width={900}
                  height={1125}
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-full h-full border border-[var(--color-soft-gold)] rounded-t-full z-0" aria-hidden="true" />
            </div>
          </div>
        </div>
      </section>

      {/* Tratamientos */}
      <section id="tratamientos" className="py-24 lg:py-32 px-6 bg-white">
        <div className="container mx-auto max-w-5xl">
          <div ref={fadeRef} className="text-center fade-in-up mb-16">
            <h2 className="text-3xl md:text-5xl mb-4 lumeskin-text-main">Nuestros Tratamientos</h2>
            <p className="text-lg lumeskin-text-light max-w-2xl mx-auto">Diseñados para renovar tu cuerpo y relajar tu mente</p>
          </div>

          <div role="tablist" aria-label="Categorías de tratamientos" className="flex overflow-x-auto no-scrollbar justify-start md:justify-center mb-12 border-b border-gray-200">
            {(Object.keys(treatments) as TreatmentKey[]).map((key) => (
              <button
                key={key}
                role="tab"
                aria-selected={activeTab === key}
                onClick={() => setActiveTab(key)}
                className={`px-6 py-4 whitespace-nowrap font-medium text-base transition-all duration-300 relative capitalize ${
                  activeTab === key ? "lumeskin-text-main" : "text-gray-400 hover:text-gray-600"
                }`}
              >
                {key}
                {activeTab === key && <div className="absolute bottom-0 left-0 w-full h-0.5 lumeskin-bg-rose" aria-hidden="true" />}
              </button>
            ))}
          </div>

          <div role="tabpanel" className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {treatments[activeTab].map((service, idx) => (
              <article key={idx} className="bg-[var(--color-cream)] p-8 rounded-2xl flex flex-col justify-between border border-[var(--color-cream-dark)] hover:shadow-lg transition-shadow">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-serif text-xl font-medium text-gray-900 leading-tight pr-4">{service.name}</h3>
                    <span className="lumeskin-text-rose font-medium whitespace-nowrap">{service.price}</span>
                  </div>
                  {"desc" in service && service.desc && (
                    <p className="text-gray-600 font-light text-sm mb-8 leading-relaxed">{service.desc}</p>
                  )}
                </div>
                <a
                  href={CTAs.treatment(service.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-auto w-full py-3 px-4 border border-[var(--color-dusty-rose)] lumeskin-text-rose rounded-full text-center hover:bg-[var(--color-dusty-rose)] hover:text-white transition-colors text-sm font-medium flex items-center justify-center gap-2 group"
                >
                  <span>Pregunta por este tratamiento</span>
                  <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" aria-hidden="true" />
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Galería */}
      <section id="galeria" className="py-24 px-6 lumeskin-bg-cream-dark">
        <div className="container mx-auto max-w-6xl">
          <div ref={fadeRef} className="text-center fade-in-up mb-16">
            <h2 className="text-3xl md:text-5xl mb-4 lumeskin-text-main">El Espacio</h2>
            <p className="text-lg lumeskin-text-light max-w-2xl mx-auto">Un santuario dedicado a tu belleza y relajación</p>
          </div>
          <div className="columns-1 md:columns-2 lg:columns-3 gap-4 space-y-4">
            {galleryImages.map(({ src, alt }, idx) => (
              <button
                key={idx}
                className="relative break-inside-avoid overflow-hidden rounded-xl cursor-pointer group w-full text-left"
                onClick={() => setLightboxImg(src)}
                aria-label={`Ver imagen: ${alt}`}
              >
                <img
                  src={src}
                  alt={alt}
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                  decoding="async"
                  width={600}
                  height={400}
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center" aria-hidden="true">
                  <div className="bg-white/80 p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 scale-75 group-hover:scale-100">
                    <Sparkles size={24} className="lumeskin-text-main" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxImg && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Imagen ampliada"
          className="fixed inset-0 z-50 bg-black/92 flex items-center justify-center p-4 md:p-8"
          onClick={() => setLightboxImg(null)}
        >
          <button
            className="absolute top-6 right-6 text-white hover:text-gray-300 transition-colors p-2"
            onClick={() => setLightboxImg(null)}
            aria-label="Cerrar imagen"
          >
            <X size={32} />
          </button>
          <img
            src={lightboxImg.replace("w=600", "w=1200")}
            alt="Imagen del spa Lumeskin"
            className="max-w-full max-h-[90vh] object-contain rounded-md"
            onClick={(e) => e.stopPropagation()}
            loading="lazy"
            decoding="async"
          />
        </div>
      )}

      {/* Reseñas */}
      <section aria-label="Opiniones de clientes" className="py-24 px-6 bg-white overflow-hidden">
        <div className="container mx-auto max-w-6xl">
          <div ref={fadeRef} className="text-center fade-in-up mb-16">
            <h2 className="text-3xl md:text-5xl mb-4 lumeskin-text-main">Lo que dicen de nosotras</h2>
          </div>
          <div className="flex overflow-x-auto no-scrollbar gap-6 pb-6 snap-x snap-mandatory">
            {reviews.map((review, idx) => (
              <article key={idx} className="snap-center shrink-0 w-[300px] md:w-[380px] bg-[var(--color-cream-dark)] p-8 rounded-2xl shadow-sm border border-[var(--color-cream)]">
                <div className="flex gap-1 mb-4" aria-label={`Calificación: ${review.rating} de 5`}>
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} size={18} className="fill-[var(--color-soft-gold)] text-[var(--color-soft-gold)]" aria-hidden="true" />
                  ))}
                </div>
                <blockquote className="text-gray-700 italic font-light mb-6 leading-relaxed">"{review.text}"</blockquote>
                <cite className="font-serif font-medium text-lg lumeskin-text-main not-italic">— {review.name}</cite>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="py-24 px-6 lumeskin-bg-cream-dark">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-0 bg-white rounded-3xl overflow-hidden shadow-xl">
            <div className="h-[400px] lg:h-auto min-h-[400px] relative">
              <iframe
                src="https://maps.google.com/maps?q=Celaya,Guanajuato,Mexico&t=&z=13&ie=UTF8&iwloc=&output=embed"
                title="Ubicación de Lumeskin en Celaya, Guanajuato"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="absolute inset-0"
              />
            </div>
            <div className="p-10 md:p-16 flex flex-col justify-center">
              <h2 className="text-3xl md:text-4xl mb-8 lumeskin-text-main">Visítanos</h2>
              <address className="space-y-6 mb-10 not-italic">
                <div className="flex items-start gap-4">
                  <MapPin className="text-[var(--color-rose-dark)] mt-1 shrink-0" size={24} aria-hidden="true" />
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Ubicación</h3>
                    <p className="text-gray-600 font-light">Celaya, Guanajuato, México<br />CP 38020</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="text-[var(--color-rose-dark)] mt-1 shrink-0" size={24} aria-hidden="true" />
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Teléfono</h3>
                    <a href="tel:+524611693332" className="text-gray-600 font-light hover:text-[var(--color-rose-dark)] transition-colors">461 169 3332</a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Clock className="text-[var(--color-rose-dark)] mt-1 shrink-0" size={24} aria-hidden="true" />
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Horario</h3>
                    <p className="text-gray-600 font-light">
                      Lun – Vie: 9:00 am – 7:00 pm<br />
                      Sábados: 9:00 am – 3:00 pm<br />
                      Domingos: cerrado
                    </p>
                  </div>
                </div>
              </address>
              <a
                href={CTAs.general}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-4 px-6 bg-[var(--color-text-main)] text-white rounded-full text-center font-medium hover:opacity-90 transition-opacity mb-6"
              >
                Agenda tu cita por WhatsApp
              </a>
              <div className="pt-6 border-t border-gray-100 flex items-center gap-4">
                <span className="text-sm text-gray-500">Síguenos:</span>
                <a
                  href="https://www.facebook.com/profile.php?id=61565968125592"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook de Lumeskin"
                  className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-600 hover:bg-[var(--color-text-main)] hover:text-white transition-colors"
                >
                  <Facebook size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="lumeskin-bg-rose text-white pt-20 pb-10 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-3 gap-12 mb-16 text-center md:text-left">
            <div>
              <div className="font-serif text-3xl tracking-widest uppercase font-bold mb-4">Lumeskin</div>
              <p className="text-white/80 font-serif italic text-lg">Tu belleza, nuestra prioridad</p>
            </div>
            <nav aria-label="Footer" className="flex flex-col space-y-4 items-center md:items-start">
              <h3 className="font-semibold mb-2">Enlaces Rápidos</h3>
              {navLinks.map(({ label, id }) => (
                <button key={id} onClick={() => scrollToSection(id)} className="text-white/80 hover:text-white transition-colors">
                  {label}
                </button>
              ))}
            </nav>
            <div className="flex flex-col items-center md:items-start">
              <h3 className="font-semibold mb-4">Conecta</h3>
              <a
                href="https://www.facebook.com/profile.php?id=61565968125592"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook de Lumeskin"
                className="w-12 h-12 rounded-full border border-white/30 flex items-center justify-center hover:bg-white hover:text-[var(--color-dusty-rose)] transition-colors"
              >
                <Facebook size={20} />
              </a>
            </div>
          </div>
          <div className="border-t border-white/20 pt-8 text-center text-white/60 text-sm">
            <p>&copy; {new Date().getFullYear()} Lumeskin. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
